﻿Project Group Members : 

Vivek Nagalapura Ravindra(vxn170230)
Vinay Nagarad Dasavandi Krishnammurthy(vxn160330)
Abhishek Murlidhar Patil(amp170830)

INSTRUCTIONS TO RUN THE PROGRAM :
1. Extract the submitted zip file.
2. Config file, java files, launcher and cleanup scripts should be in the current working directory.
3. Before running the launcher script type command chmod +x launcher.sh cleanup.sh
4. Run the launcher script : 
> sh launcher.sh [configFilename] [netId]
5. Run the cleanup script to kill all the processes before running the program again : 
> sh cleanup.sh [configFilename] [netId]
6. The output files [configFilename-nodeId.out] files will be generated in the current working directory.



 
